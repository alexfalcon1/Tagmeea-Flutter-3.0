import 'package:flutter/material.dart';

import '../page_template_overlay.dart';

class RegisterPage extends StatelessWidget {
  const RegisterPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PageTemplateOverlay(
      content: Container(),
    );
  }
}
