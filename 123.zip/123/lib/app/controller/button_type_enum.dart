enum BtnColorEnum {
  primary,
  secondary,
  success,
  danger,
  warning,
  info,
  normal,
  disabled,
}
