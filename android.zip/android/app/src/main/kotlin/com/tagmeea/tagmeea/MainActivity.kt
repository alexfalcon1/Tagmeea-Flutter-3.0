package net.tagmee3.tagmee3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
